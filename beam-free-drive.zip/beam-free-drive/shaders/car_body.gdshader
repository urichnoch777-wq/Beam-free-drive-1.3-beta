shader_type spatial;
render_mode cull_disabled;

// Кузов деформируется вместе с решёткой мягкого тела (8 сечений x 2 яруса x 3 колонны).
uniform vec3 nodes[48];
uniform float st_z[8];
uniform float st_top[8];
uniform float st_floor[8];
uniform float st_wt[8];
uniform float wf = 1.0;
uniform mat3 car_basis;
uniform vec3 paint_color : source_color = vec3(0.6, 0.03, 0.04);

const vec3 PAL[10] = vec3[10](
    vec3(0.6, 0.03, 0.04), vec3(0.03, 0.05, 0.07), vec3(0.03, 0.03, 0.035), vec3(0.75, 0.76, 0.8),
    vec3(0.95, 0.95, 0.88), vec3(0.03, 0.03, 0.03), vec3(0.12, 0.12, 0.13), vec3(0.35, 0.35, 0.37),
    vec3(0.6, 0.03, 0.04), vec3(0.09, 0.09, 0.1));
const float ROUGH[10] = float[10](0.25, 0.05, 0.55, 0.15, 0.2, 0.9, 0.35, 0.5, 0.4, 0.5);
const float METAL[10] = float[10](0.35, 0.5, 0.0, 1.0, 0.0, 0.0, 0.8, 0.8, 0.0, 0.3);

varying float cls;

void vertex() {
    vec3 p = VERTEX;
    int i = 0;
    for (int s = 1; s < 7; s++) {
        if (p.z > st_z[s]) {
            i = s;
        }
    }
    float u = (p.z - st_z[i]) / (st_z[i + 1] - st_z[i]);
    float fl = mix(st_floor[i], st_floor[i + 1], u);
    float tp = mix(st_top[i], st_top[i + 1], u);
    float v = (p.y - fl) / (tp - fl);
    float hb = mix(wf, st_wt[i], v);
    float hc = mix(wf, st_wt[i + 1], v);
    float hw = mix(hb, hc, u);
    float t = (p.x / hw * 0.5 + 0.5) * 2.0;
    int k = clamp(int(floor(t)), 0, 1);
    float w = t - float(k);
    int b0 = (i * 2) * 3 + k;
    int b1 = (i * 2 + 1) * 3 + k;
    int b2 = ((i + 1) * 2) * 3 + k;
    int b3 = ((i + 1) * 2 + 1) * 3 + k;
    vec3 a0 = mix(nodes[b0], nodes[b0 + 1], w);
    vec3 a1 = mix(nodes[b1], nodes[b1 + 1], w);
    vec3 c0 = mix(nodes[b2], nodes[b2 + 1], w);
    vec3 c1 = mix(nodes[b3], nodes[b3 + 1], w);
    VERTEX = mix(mix(a0, a1, v), mix(c0, c1, v), u);
    NORMAL = car_basis * NORMAL;
    cls = COLOR.a;
}

void fragment() {
    int c = int(cls * 10.0 + 0.5);
    vec3 col = PAL[c];
    if (c == 0) {
        col = paint_color;
    }
    ALBEDO = col;
    ROUGHNESS = ROUGH[c];
    METALLIC = METAL[c];
}
